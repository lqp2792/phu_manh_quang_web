<div class="full_w">
    <div class="h_title">Error(s)!</div>
    <?php
        foreach($error as $msg) {
            echo '<div class="n_error"><p>'."- $msg".'</p></div>';
        }
    ?>
</div>
