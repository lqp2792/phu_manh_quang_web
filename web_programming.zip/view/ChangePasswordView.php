<div class="full_w">
    <div class="h_title">Change Password</div>
    <form action="Account/ChangePassword/" method="post">
        <table>
            <tr>
                <td>Old Password:</td>
                <td><input type="password" name="old_password" /></td>
            </tr>
            <tr>
                <td>New Password:</td>
                <td><input type="password" name="new_password" /></td>
            </tr>
            <tr>
                <td>Confirm new Password:</td>
                <td><input type="password" name="confirm_password" /></td>
            </tr>
            <tr>
                <td><input class="button" type="submit" name="submit" value="Change Password" /></td>
            </tr>
        </table>
    </form>
</div>
