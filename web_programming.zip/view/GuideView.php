<div class="full_w">
    <div class="h_title">Web Guide</div>
    <h2>REGISTER AN ACCOUNT</h2>
    <p>You have to register an account for taking our services</p>
    <h2>ACCOUNT PANEL</h2>
    <p>After login, you can look at account panel</p>
    <p>Our account panel support you that: </p>
    <ul>
        <li>Add new Question to our database</li>
        <li>Take a random test with specific field: Vocabulary, Read, Grammar</li>
        <li>Take a random test belong to some exams like: TOEFL, TOEIC ...</li>
        <li>You can check your test history</li>
        <li>Our system save all users's score and total score</li>
    </ul>
    <p>In future, we will update other kind of test: Listening</p>
</div>
