<div class="full_w">
    <div class="h_title">Forgotten Password ?</div>
    <form action="Homepage/Forgot/" method="post">
        <table>
            <tr>
                <td>Username:</td>
                <td><input type="text" name="username" /></td>
            </tr>
            <tr>
                <td>Email:</td>
                <td><input type="text" name="email" /></td>
            </tr>
            <tr>
                <td><input class="button" type="submit" name="submit" value="Send Password to email" /></td>
            </tr>
        </table>
    </form>
</div>
