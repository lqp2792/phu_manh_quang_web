<div class="full_w">
    <div class="h_title">Result!</div>
    <?php
        echo '<div class="n_ok"><p>Successful</p></div>';
        echo '<p>Username:'.$_POST['username'].'</p>';
        echo '<p>First Name:'.$_POST['first_name'].'</p>';
        echo '<p>Last Name:'.$_POST['last_name'].'</p>';
        echo '<p>Email:'.$_POST['email'].'</p>';
        echo '<p>Go <a href="Homepage/">back</a> to homepage</p>';
    ?>
</div>
