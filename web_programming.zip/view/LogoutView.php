<div class="full_w">
    <div class="h_title">Log out</div>
    <?php
        echo '<p>Logged out!</p>';
    ?>
</div>
