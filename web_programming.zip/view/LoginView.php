<div class="full_w">
    <div class="h_title">Login</div>
    <form action="Homepage/Login/" method="post">
        <label for="login">Username:</label>
        <input class="text" type="text" name="username" />
        <label for="pass">Password:</label>
        <input class="text" type="password" name="password"  />
        <div class="sep"></div>
        <button class="ok" type="submit" name="submit">Login</button> <a class="button" href="Homepage/Forgot/">Forgotten password?</a>
    </form>
</div>
