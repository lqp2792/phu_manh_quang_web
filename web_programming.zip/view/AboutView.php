<div class="full_w">
    <div class="h_title">About us!</div>
    <h2>DEVELOPERS</h2>
    <p>We are students of HEDSPI, an Japan project at Ha noi Bach Khoa college</p>
    <ul>
        <li>-  Le Quang Phu</li>
        <li>-  Vu The Manh</li>
        <li>-  Do Duc Quang</li>
    </ul>
    <p>We made this website for our subject at colledge and learning basic knowlegde about web programming</p>
    <p>This is our first time at web programming, so maybe some bugs will apear when you use our service !</p>
</div>